// Created: 2021/02/09 10:51:54
// Last modified: 2021/05/27 09:52:25

var cmx_data;

$.getJSON("websitedata.json", function (json) {
    console.log( "Data success" );
    cmx_data = json;

    $(document).prop('title', cmx_data.location + ' weather');
    $('meta[name=description]').attr('content', cmx_data.location + ' weather data');
    $('meta[name=keywords]').attr('content', $('meta[name=keywords]').attr('content') + ', ' + cmx_data.location + ' weather data');

    // Update all spans having data-cmxdata with data values
    $('[data-cmxdata]').each(function () {
        if (this.dataset.cmxdata == 'forum' || this.dataset.cmxdata == 'webcam') {
            this.innerHTML = cmx_data[this.dataset.cmxdata];
        } else {
            this.innerText = cmx_data[this.dataset.cmxdata];
        }
    });

    // Use this to trigger other scripts on the page
    $('#cmx-location').trigger('change')
})
.fail(function (jqxhr, textStatus, error) {
    var err = textStatus + ', ' + error;
    console.log('Data Request Failed: ' + err );
});
